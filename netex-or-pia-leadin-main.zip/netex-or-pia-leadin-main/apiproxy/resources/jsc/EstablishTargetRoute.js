var reqVerb = context.getVariable("request.verb"),
    targetConfig = context.getVariable("targetConfig"),
    defaultRoute = true;

// Openreach backend path
var targetPath = "/manageLeadIn/v1/product";

if (reqVerb !== "POST") {
    defaultRoute = false;
}

context.setVariable("defaultRoute", defaultRoute);
context.setVariable("targetServerBasePath", targetPath);
context.setVariable("target.url", targetConfig + targetPath);
context.setVariable("target.copy.pathsuffix", false);