var responseBody = context.getVariable("error.content") ||

    context.getVariable("response.content") ||

    context.getVariable("message.content");

var transactionId = context.getVariable("request.header.X-Transaction-Id") || context.getVariable("messageid");

var timestamp = new Date().toISOString();

try {

    var parsedBody = JSON.parse(responseBody);

    var errorCode = parsedBody.code || "UNKNOWN";

    var errorReason = parsedBody.reason || "An unexpected error occurred.";

    var errorResponse = {

        code: 400,

        success: false,

        timeStamp: timestamp,

        transactionId: transactionId,

        error: {

            errorSource: "OpenReach API Error",

            errorType: "HTTP::BAD_REQUEST",

            errorDescription: "OR_ErrorCode: " + errorCode + ", OR_ErrorMessage: " + errorReason

        }

    };

    context.setVariable("response.status.code", 400);

    context.setVariable("response.reason.phrase", "Bad Request");

    context.setVariable("response.header.Content-Type", "application/json");

    context.setVariable("response.content", JSON.stringify(errorResponse));

} catch (e) {

    var fallbackResponse = {

        code: 400,

        success: false,

        timeStamp: timestamp,

        transactionId: transactionId,

        error: {

            errorSource: "OpenReach API Error",

            errorType: "HTTP::BAD_REQUEST",

            errorDescription: "Failed to process error response from target."

        }

    };

    context.setVariable("response.status.code", 400);

    context.setVariable("response.reason.phrase", "Bad Request");

    context.setVariable("response.header.Content-Type", "application/json");

    context.setVariable("response.content", JSON.stringify(fallbackResponse));

}