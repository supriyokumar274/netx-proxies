var credential = context.getVariable("kvm.credential");
var parts = credential.split(":");
context.setVariable("or_client_id", parts[0]);
context.setVariable("or_client_secret", parts[1]);

