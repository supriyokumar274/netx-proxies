//developed by k1434171//
var pathSuffix = context.getVariable('proxy.pathsuffix'),
    reqVerb = context.getVariable('request.verb'),
    structure = context.getVariable("requestData.structure"),
    duct = context.getVariable("requestData.duct"),
    targetConfig = context.getVariable("targetConfig"),
    concatQueryParams = "",
    basePath = "/requestInventoryData/v1",
    defaultRoute = true;
    queryParams = context.getVariable("request.querystring") || ""; 
       
if (queryParams !== "" && queryParams !== null && queryParams !== undefined) {
    concatQueryParams = "?" + queryParams;
}
if (pathSuffix === "/inventorydata/collection/feature/structure" && reqVerb === "GET") {
    basePath += "/featureCollection/structure" + concatQueryParams;
}
    else if (pathSuffix === "/inventorydata-async/collection/feature/structure" && reqVerb === "GET") {
    basePath += "/featureCollectionAsync/structure" + concatQueryParams;
}  
  if (pathSuffix === "/inventorydata/collection/feature/duct" && reqVerb === "GET") {
    basePath += "/featureCollection/duct" + concatQueryParams;
}
    else if (pathSuffix === "/inventorydata-async/collection/feature/duct" && reqVerb === "GET") {
    basePath += "/featureCollectionAsync/duct" + concatQueryParams;
}  
    else {
        defaultRoute = false;
    }
context.setVariable('defaultRoute', defaultRoute);
context.setVariable('targetServerBasePath', basePath);
context.setVariable("target.url", targetConfig + basePath);
context.setVariable("target.copy.pathsuffix", false);