//error handler written by Supriyo(Accenture)
var responseBody = context.getVariable("error.content") ||
    context.getVariable("response.content") ||
    context.getVariable("message.content");
 
var fallbackStatusCode = context.getVariable("message.status.code") ||
    context.getVariable("response.status.code") || 500;
 
var errorResponse;
 
if (fallbackStatusCode == 404) {
    errorResponse = {
        code: "10-0-100" + fallbackStatusCode,
        severity: "ERROR",
        description: "Not Found",
        sourceSystem: "Target"
    };
} else {
    try {
        var parsedBody = JSON.parse(responseBody);
        var statusCode = (parsedBody.status && parsedBody.status.code) || fallbackStatusCode;
        var statusMessage = (parsedBody.status && parsedBody.status.message) || "An unexpected error occurred.";
 
        errorResponse = {
            code: "10-0-100" + statusCode,
            severity: "ERROR",
            description: statusMessage,
            sourceSystem: "Target"
        };
    } catch (e) {
        errorResponse = {
            code: "10-0-100" + fallbackStatusCode,
            severity: "ERROR",
            description: "Failed to process error response from target.",
            sourceSystem: "Target"
        };
    }
}
 
context.setVariable("response.status.code", fallbackStatusCode);
context.setVariable("response.header.Content-Type", "application/json");
context.setVariable("response.content", JSON.stringify(errorResponse));