////error handler for no body backend written by Supriyo(Accenture)
var statusCode = context.getVariable("message.status.code") ||
    context.getVariable("response.status.code") || 500;
 
var descriptionMap = {
    400: "one or more mandatory parameters are missing",
    404: "Not Found"
};
 
var errorResponse = {
    code: "10-0-100" + statusCode,
    severity: "ERROR",
    description: descriptionMap[statusCode] || "An unexpected error occurred.",
    sourceSystem: "Target"
};
 
context.setVariable("response.status.code", statusCode);
context.setVariable("response.header.Content-Type", "application/json");
context.setVariable("response.content", JSON.stringify(errorResponse));