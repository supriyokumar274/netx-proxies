//written by supriyo (Accenture)
var authHeader = context.getVariable("request.header.Authorization");

var bucket = context.getVariable("request.queryparam.bucketName");
var folderPath = context.getVariable("request.queryparam.path");
var docName = context.getVariable("request.queryparam.documentName");
 
 
var missingFields = [];
 
if (!authHeader || authHeader.trim() === "") {
    missingFields.push("Authorization header");
}


if (!bucket || bucket.trim() === "") {
    missingFields.push("bucketName query parameter");
}
 
if (!folderPath || folderPath.trim() === "") {
    missingFields.push("path query parameter");
}

if (!docName || docName.trim() === "") {
    missingFields.push("documentName query parameter");
}
 
if (missingFields.length > 0) {
    context.setVariable("custom.validation.failed", true);
    context.setVariable("custom.validation.message", "Missing mandatory field(s): " + missingFields.join(", ") + ".");
} else {
    context.setVariable("custom.validation.failed", false);
}