//written by Supriyo(Accenture)

var bucket = context.getVariable("request.queryparam.bucketName");
var folderPath = context.getVariable("request.queryparam.path");
var docName = context.getVariable("request.queryparam.documentName");



var fullPath = folderPath + "/" + docName;
var encodedPath = encodeURIComponent(fullPath);
context.setVariable("custom.encodedObjectPath", encodedPath);
 