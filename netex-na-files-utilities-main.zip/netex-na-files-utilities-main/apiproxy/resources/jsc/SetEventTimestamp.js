var d = new Date();

var isoDate = new Date().toISOString();
 
var formattedDate = isoDate.replace(/[-:]/g, '').split('.')[0];
 
context.setVariable("custom.requestedDate", formattedDate);
context.setVariable("custom.eventTimestamp", d.toISOString());