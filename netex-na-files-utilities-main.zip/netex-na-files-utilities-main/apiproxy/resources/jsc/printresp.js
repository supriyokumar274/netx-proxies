print("Event Proxy Response: " + context.getVariable("eventResponse.content"));
print("gcsUploadResponse Response: " + context.getVariable("gcsUploadResponse.content"));