//written by supriyo (Accenture)
var authHeader = context.getVariable("request.header.Authorization");
var xcorrelationid = context.getVariable("request.header.x-correlation-id");
 
var actionParam = context.getVariable("request.queryparam.action");
var documentNameParam = context.getVariable("request.queryparam.documentName");
 
var missingFields = [];
 
if (!authHeader || authHeader.trim() === "") {
    missingFields.push("Authorization header");
}

if (!xcorrelationid || xcorrelationid.trim() === "") {
    missingFields.push("x-correlation-id header");
} 

if (!actionParam || actionParam.trim() === "") {
    missingFields.push("action query parameter");
}
 
if (!documentNameParam || documentNameParam.trim() === "") {
    missingFields.push("documentName query parameter");
}
 
if (missingFields.length > 0) {
    // Using "custom." instead of "request." to avoid Apigee system conflicts
    context.setVariable("custom.validation.failed", true);
    context.setVariable("custom.validation.message", "Missing mandatory field(s): " + missingFields.join(", ") + ".");
} else {
    context.setVariable("custom.validation.failed", false);
}