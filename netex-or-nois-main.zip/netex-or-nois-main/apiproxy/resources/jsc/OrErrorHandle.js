var statusCode = context.getVariable("response.status.code") || 400;
var reasonPhrase = context.getVariable("response.reason.phrase") || "Bad Request";
 
var responseBody = context.getVariable("error.content") ||
                   context.getVariable("response.content") ||
                   context.getVariable("message.content");
 
var transactionId = context.getVariable("request.header.X-Transaction-Id") || context.getVariable("messageid");
var timestamp = new Date().toISOString();
 
try {
    var parsedBody = JSON.parse(responseBody);
    var errorCode = "UNKNOWN";
    var errorReason = "An unexpected error occurred.";
 
    // 1. Check if the error is inside the "productOrderMessages" array
    if (parsedBody.productOrderMessages && parsedBody.productOrderMessages.length > 0) {
        errorCode = parsedBody.productOrderMessages[0].code || "UNKNOWN";
        errorReason = parsedBody.productOrderMessages[0].reason || "An unexpected error occurred.";
    } 
    // 2. Fallback to the original root-level format if array doesn't exist
    else {
        errorCode = parsedBody.code || "UNKNOWN";
        errorReason = parsedBody.reason || "An unexpected error occurred.";
    }
 
    var errorResponse = {
        code: parseInt(statusCode, 10),
        success: false,
        timeStamp: timestamp,
        transactionId: transactionId,
        error: {
            errorSource: "OpenReach API Error",
            errorType: "HTTP::" + reasonPhrase.toUpperCase().replace(/\s+/g, '_'),
            errorDescription: "OR_ErrorCode: " + errorCode + ", OR_ErrorMessage: " + errorReason
        }
    };
 
    context.setVariable("response.status.code", statusCode);
    context.setVariable("response.reason.phrase", reasonPhrase);
    context.setVariable("response.header.Content-Type", "application/json");
    context.setVariable("response.content", JSON.stringify(errorResponse));
 
} catch (e) {
    var fallbackResponse = {
        code: parseInt(statusCode, 10),
        success: false,
        timeStamp: timestamp,
        transactionId: transactionId,
        error: {
            errorSource: "OpenReach API Error",
            errorType: "HTTP::" + reasonPhrase.toUpperCase().replace(/\s+/g, '_'),
            errorDescription: "Failed to process error response from target."
        }
    };
 
    context.setVariable("response.status.code", statusCode);
    context.setVariable("response.reason.phrase", reasonPhrase);
    context.setVariable("response.header.Content-Type", "application/json");
    context.setVariable("response.content", JSON.stringify(fallbackResponse));
}