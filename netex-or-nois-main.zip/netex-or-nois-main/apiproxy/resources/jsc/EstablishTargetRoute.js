//developed by k1434171//
var pathSuffix = context.getVariable('proxy.pathsuffix'),
    reqVerb = context.getVariable('request.verb'),
    noiId = context.getVariable("requestData.noiId"),
    duct = context.getVariable("requestData.duct"),
    targetConfig = context.getVariable("targetConfig"),
    concatQueryParams = "",
    basePath = "/manageNOI/v1/resourceOrderManagement/resourceOrder",
    defaultRoute = true;
    queryParams = context.getVariable("request.querystring") || ""; 
       
if (queryParams !== "" && queryParams !== null && queryParams !== undefined) {
    concatQueryParams = "?" + queryParams;
}
if (pathSuffix === "/order/resources/noi/create" && reqVerb === "POST") {
    basePath += "" + concatQueryParams;
}
    else if (pathSuffix === "/order/resources/noi/view" + "/" + noiId  && reqVerb === "GET") {
    basePath += "/" + noiId + concatQueryParams;
}  
      else if (pathSuffix === "/order/resources/noi/modify" + "/" + noiId  && reqVerb === "PATCH") {
    basePath += "/" + noiId + concatQueryParams;
} 
     else if (pathSuffix === "/order/resources/noi/delete" + "/" + noiId  && reqVerb === "DELETE") {
    basePath += "/" + noiId + concatQueryParams;
}   
     else if (pathSuffix === "/order/product-order" + "/" + noiId  && reqVerb === "GET") {
    basePath = "/managePIAOrder/v1/productOrderManagement/productOrder" + "/" + noiId + concatQueryParams;
} 
    else {
        defaultRoute = false;
        basePath = "/none"
    }
context.setVariable('defaultRoute', defaultRoute);
context.setVariable('targetServerBasePath', basePath);
context.setVariable("target.url", targetConfig + basePath);
context.setVariable("target.copy.pathsuffix", false);