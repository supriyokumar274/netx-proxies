var backend = JSON.parse(context.getVariable("response.content"));

var response = {
    code: 200,
    success: true,
    timeStamp: new Date().toISOString(),
    transactionId: context.getVariable("messageid"),
    result: {
        totalRecords: backend.totalRecords,
        referenceData: backend.referenceData
    }
};

context.setVariable("response.content", JSON.stringify(response));