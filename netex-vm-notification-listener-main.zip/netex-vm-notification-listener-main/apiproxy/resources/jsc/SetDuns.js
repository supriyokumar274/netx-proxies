var path = context.getVariable("proxy.pathsuffix");

if (path.indexOf("/nexfibre/openreach/kci") === 0) {
    context.setVariable("apigee.dunsHeader", "225312765");
} else {
    // Openreach/VMO2
    context.setVariable("apigee.dunsHeader", "231084661");
}