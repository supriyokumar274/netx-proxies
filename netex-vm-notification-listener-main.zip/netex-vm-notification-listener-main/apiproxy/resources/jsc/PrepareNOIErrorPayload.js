// Original request received from Openreach
var originalPayload = JSON.parse(context.getVariable("flow.originalPayload"));

// Response received from KCI Ingestion CF
var responseContent = context.getVariable("response.content");
var statusCode = context.getVariable("response.status.code");

// Correlation Id
var transactionId =
    context.getVariable("request.header.correlationId") ||
    context.getVariable("correlationId");

// Client App
var eventSender =
    context.getVariable("client.app") ||
    context.getVariable("secure.client.app");

var errorObj = {};

try {
    errorObj = JSON.parse(responseContent);

    // If response is from CDH, extract the nested error object
    if (errorObj.detail && errorObj.detail.error) {
        errorObj = errorObj.detail.error;
    }

} catch (e) {
    errorObj = {
        errorDescription: responseContent
    };
}

var noiPayload = {
    event: {
        isSuccess: false,
        code: statusCode,
        type: "NETWORK_ADJUSTMENT_PUBLISH_KCI_FAILED",
        eventSender: eventSender,
        eventTimestamp: new Date().toISOString(),
        transactionId: transactionId,
        data: {
            kciType: "API",
            kciPayload: originalPayload
        },
        error: {
            errorSource: errorObj.errorSource || "",
            errorType: errorObj.errorType || "",
            errorDescription: errorObj.errorDescription || responseContent
        }
    }
};

context.setVariable("flow.noi.payload", JSON.stringify(noiPayload));
context.setVariable("request.header.Content-Type", "application/json");