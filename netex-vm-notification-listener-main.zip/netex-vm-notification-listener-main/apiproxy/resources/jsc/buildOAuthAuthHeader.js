var duns = context.getVariable("apigee.dunsHeader");
 
if (duns === "231084661") {
 
    context.setVariable(

        "or_client_id",

        context.getVariable("private.vmo2.client.id")

    );
 
    context.setVariable(

        "or_client_secret",

        context.getVariable("private.vmo2.client.secret")

    );
 
} else if (duns === "225312765") {
 
    context.setVariable(

        "or_client_id",

        context.getVariable("private.nexfibre.client.id")

    );
 
    context.setVariable(

        "or_client_secret",

        context.getVariable("private.nexfibre.Client.Secret")

    );

}
 