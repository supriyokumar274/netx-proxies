var duns = context.getVariable("apigee.dunsHeader");
 
// 2. Initialize variables for our generic targets
var selectedId = "";
var selectedSecret = "";
 
// 3. Segregate based on the DUNS ID value
if (duns === "231084661") {
    // It's VMO2 -> Grab the VMO2 variables you extracted from KVM
    selectedId = context.getVariable("private.transflex.vmo2.client.id");
    selectedSecret = context.getVariable("private.transflex.vmo2.client.secret");
} else if (duns === "225312765") {
    // It's Nexfibre -> Grab the Nexfibre variables you extracted from KVM
    selectedId = context.getVariable("private.transflex.nexfibre.client.id");
    selectedSecret = context.getVariable("private.transflex.nexfibre.client.secret");
}
 
// 4. Set the generic variables that the Basic Auth policy will use
context.setVariable("private.transflex_id", selectedId);
context.setVariable("private.transflex_sec", selectedSecret);