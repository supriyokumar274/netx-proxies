// Downloads the inventory file directly from the pre-signed S3 URL.
//
// A ServiceCallout mangles this call: Apigee rebuilds the request line from the
// request message / <URL>, which either drops the path+query (requesturi "/") or
// re-encodes the SigV4 query string -> 403 SignatureDoesNotMatch.
//
// httpClient.send() transmits the URL byte-for-byte, so the pre-signed path and
// query (X-Amz-Signature, X-Amz-Credential, X-Amz-Security-Token) reach S3 exactly
// as signed. download.url is set by ExtractDownloadUrl.js (scheme stripped).

var url = "https://" + context.getVariable("download.url");

var exchange = httpClient.send(new Request(url, "GET"));
exchange.waitForComplete();

var response = exchange.getResponse();
var status = response.status;

// Expose the result under downloadResponse.* so SC-GCS-UploadFile can upload
// {downloadResponse.content} unchanged.
context.setVariable("downloadResponse.status.code", status);
context.setVariable("downloadResponse.content", response.content);

if (status < 200 || status >= 300) {
    throw "SC-DownloadFile: pre-signed download failed with HTTP " + status;
}
