var authHeader = context.getVariable("request.header.Authorization");

if (authHeader && authHeader.startsWith("JWS")) {

    // Remove "JWS "
    var token = authHeader.replace("JWS ", "").trim();
    context.setVariable("jws.token", token);
 

    // Split JWT using DOT
    var parts = token.split(".");

    // JWT must have 3 parts
    if (parts.length == 3) {

        context.setVariable("jws.header", parts[0]);
        context.setVariable("jws.payload", parts[1]);
        context.setVariable("jws.signature", parts[2]);

        context.setVariable("jws.parse.success", true);

    } else {

        context.setVariable("jws.parse.success", false);

        context.setVariable(
            "flow.error.reason",
            "JWS::PARSE_ERROR"
        );
    }

} else {

    context.setVariable("jws.parse.success", false);

    context.setVariable(
        "flow.error.reason",
        "JWS::INVALID_FORMAT"
    );
}