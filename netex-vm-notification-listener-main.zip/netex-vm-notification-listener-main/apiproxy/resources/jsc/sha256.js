// Get the value to hash

var input = context.getVariable("request.content");
 
// Create SHA256 object

var sha256 = crypto.getSHA256();
 
// Add data to the hash

sha256.update(input);
 
// Generate hexadecimal digest

var hashValue = sha256.digest();
 
// Store in a flow variable

context.setVariable("sha256.hash", hashValue);
 