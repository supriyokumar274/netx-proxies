var response = context.getVariable("calloutResponse.content");

if (response) {
    var json = JSON.parse(response);
    var url = json.url;

    if (url && url.indexOf("https://") === 0) {
        url = url.substring(8);   // Remove "https://"
    }

    context.setVariable("download.url", url);
}