var eventType = context.getVariable("eventType");
var orderSubType = context.getVariable("orderSubType");

// Event Type Missing
if (!eventType) {

    context.setVariable("flow.kci.unsupported", true);
    context.setVariable("flow.error.reason", "Event type missing");

}

// Network Inventory - Document Created
else if (eventType === "Document Created") {

    context.setVariable("flow.kci.document.created", true);
    context.setVariable("flow.kci.type", "NI");
    context.setVariable("flow.kci.unsupported", false);

}

// Network Inventory - Document Failed
else if (eventType === "Document Failed") {

    context.setVariable("flow.kci.document.failed", true);
    context.setVariable("flow.kci.type", "NI");
    context.setVariable("flow.kci.unsupported", false);

}

// Network Adjustment
else if (orderSubType === "Network Adjustment") {

    context.setVariable("flow.kci.type", "NA");
    context.setVariable("flow.kci.unsupported", false);

}

// Unsupported
else {

    context.setVariable("flow.kci.unsupported", true);
    context.setVariable("flow.error.reason", "Wrong event type - Event type not supported");

}