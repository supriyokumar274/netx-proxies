var fullHeader = context.getVariable("private.Or_Authorization");
 
if (fullHeader) {
    var cleanToken = fullHeader.replace(/^Basic\s+/i, '').trim(); 
    // It is highly recommended to store the CLEAN token in a private variable too!
    context.setVariable("private.Or_Authorization_Clean", cleanToken); 
}