var receivedDigest =
    context.getVariable("jwt.JWT-DecodeDigest.claim.digest");
 
var computedDigest =
    context.getVariable("sha256.hash");
 
if (!receivedDigest) {
 
    context.setVariable(
        "flow.error.reason",
        "JWS::DIGEST_NOT_FOUND"
    );
 
    throw new Error(
        "Digest not found"
    );
}
 
if (
    computedDigest.toLowerCase() !==
    receivedDigest.toLowerCase()
) {
 
    context.setVariable(
        "flow.error.reason",
        "JWS::DIGEST_MISMATCH"
    );
 
    throw new Error(
        "Digest mismatch"
    );
}
 
context.setVariable(
    "digest.validation.success",
    true
);