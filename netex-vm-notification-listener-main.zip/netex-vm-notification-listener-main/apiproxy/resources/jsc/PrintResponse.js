var scresponse = context.getVariable("calloutResponse.content");
var scstatus = context.getVariable("calloutResponse.status.code");
context.setVariable("response.content", scresponse);
context.setVariable("response.status.code", scstatus); // or calloutResponse.status.code
context.setVariable("response.header.Content-Type", "application/json");