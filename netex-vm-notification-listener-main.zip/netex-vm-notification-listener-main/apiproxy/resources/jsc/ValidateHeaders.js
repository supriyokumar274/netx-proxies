var authHeader = context.getVariable("request.header.Authorization");
var dunsHeader = context.getVariable("request.header.DUNS");

// Authorization Header Validation
if (!authHeader || authHeader.trim() === "") {

    context.setVariable("flow.error.status.code", "500");
    context.setVariable("flow.error.reason", "JWS::TOKEN_MISSING");
    context.setVariable("flow.error.message", "Authorization header is missing");

    throw new Error("JWS::TOKEN_MISSING");
}
 
// // DUNS Header Validation

// if (!dunsHeader || dunsHeader.trim() === "") {

//     // Check 1: DUNS is completely missing or empty

//     context.setVariable("flow.error.status.code", "500");

//     context.setVariable("flow.error.reason", "OPENREACH::INVALID_DUNS");

//     context.setVariable("flow.error.message", "DUNS header is missing");

//     throw new Error("OPENREACH::INVALID_DUNS");

// } 

// else {

//     // Trim the input to make sure accidental whitespace doesn't fail the check

//     var cleanDuns = dunsHeader.trim(); 

//     // Check 2: DUNS is present but doesn't match either allowed value

//     if (cleanDuns !== "231084661" && cleanDuns !== "225312765") {

//         context.setVariable("flow.error.status.code", "500");

//         context.setVariable("flow.error.reason", "OPENREACH::INVALID_DUNS");

//         context.setVariable("flow.error.message", "Invalid DUNS");

//         throw new Error("OPENREACH::INVALID_DUNS");

//     }

//}
 