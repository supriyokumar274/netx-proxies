// Builds the GCS object name using the convention:
//   rw/or/network-inventory-data-yyyyMMddHHmmssSSS.json
// Timestamp is UTC so file names are consistent regardless of runtime timezone.

function pad(value, width) {
    var s = String(value);
    while (s.length < width) {
        s = "0" + s;
    }
    return s;
}

var now = new Date();

var timestamp =
    pad(now.getUTCFullYear(), 4) +
    pad(now.getUTCMonth() + 1, 2) +
    pad(now.getUTCDate(), 2) +
    pad(now.getUTCHours(), 2) +
    pad(now.getUTCMinutes(), 2) +
    pad(now.getUTCSeconds(), 2) +
    pad(now.getUTCMilliseconds(), 3);

var objectName = "rw/or/network_inventory/network-inventory-data-" + timestamp + ".json";
var fileName= "network-inventory-data-"  + timestamp + ".json";

// The GCS JSON upload API takes the object name via the "name" query parameter,
// so the path separators must be URL-encoded (/ -> %2F).
context.setVariable("gcs.objectName", objectName);
context.setVariable("gcs.fileName", fileName);
context.setVariable("gcs.objectNameEncoded", encodeURIComponent(objectName));
