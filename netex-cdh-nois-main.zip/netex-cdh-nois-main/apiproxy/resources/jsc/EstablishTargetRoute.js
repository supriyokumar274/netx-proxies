//developerd by SUPRIYO(Accenture)
var pathSuffix = context.getVariable('proxy.pathsuffix'),
    reqVerb = context.getVariable('request.verb'),
    // noiId = context.getVariable("requestData.noiId"),
    // duct = context.getVariable("requestData.duct"),
    targetConfig = context.getVariable("targetConfig"),
    concatQueryParams = "",
    basePath = "",
    defaultRoute = true;
    queryParams = context.getVariable("request.querystring") || ""; 
       
if (queryParams !== "" && queryParams !== null && queryParams !== undefined) {
    concatQueryParams = "?" + queryParams;
}
if (pathSuffix === "/create" && reqVerb === "POST") {
    basePath += "/create-noi" + concatQueryParams;
}
    else if (pathSuffix === "/view"  && reqVerb === "GET") {
    basePath += "/view-noi" + concatQueryParams;
}  
      else if (pathSuffix === "/update" ) {
    basePath += "/update-noi" + concatQueryParams;
} 
    else {
        defaultRoute = false;
        basePath = "/none"
    }
context.setVariable('defaultRoute', defaultRoute);
context.setVariable('targetServerBasePath', basePath);
context.setVariable("target.url", targetConfig + basePath);
context.setVariable("target.copy.pathsuffix", false);