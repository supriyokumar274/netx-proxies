//developerd by SUPRIYO(Accenture)
var checkedParams = ["$select", "$filter", "$orderby", "$skip", "$top"];
var emptyParams = [];
 
for (var i = 0; i < checkedParams.length; i++) {
    var paramName = checkedParams[i];
    var paramValue = context.getVariable("request.queryparam." + paramName);
    // Check if the parameter was provided (not null) AND if it's empty/blank
    if (paramValue !== null && paramValue.trim() === "") {
        emptyParams.push(paramName);
    }
}
 

if (emptyParams.length > 0) {
    context.setVariable("isValidODataRequest", "false");
    var errorMsg = "The following provided query parameter(s) cannot be empty: " + emptyParams.join(", ");
    context.setVariable("odata.validation.error.message", errorMsg);
} else {
    context.setVariable("isValidODataRequest", "true");
}