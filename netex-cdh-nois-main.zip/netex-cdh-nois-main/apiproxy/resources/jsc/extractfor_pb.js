try {
    var dunsId = context.getVariable("request.header.DUNS") || "";
    var transactionId = context.getVariable("request.header.x-correlation-id") || "";

    var rawContent = context.getVariable("request.content");
    var noiId = "";

    if (rawContent) {
        var payload = JSON.parse(rawContent);
        noiId = payload.noiId || "";
    }

    context.setVariable("noiId", noiId);
    context.setVariable("dunsId", dunsId);
    context.setVariable("transactionId", transactionId);
    context.setVariable("topic_name", "event_hub_noi");


} catch (e) {
    context.setVariable("extract.error", "Failed to extract variables: " + e.message);
}
 