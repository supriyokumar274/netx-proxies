// developed by SUPRIYO(Accenture)
context.setVariable("netex.error.timestamp", new Date().toISOString());


context.setVariable("isNetexCallSuccess", "false");
context.setVariable("isNetexExpiredNoI", "false");

try {
    var rawContent = context.getVariable("netexResponse.content");
    var dunsId = context.getVariable("request.header.DUNS") || "";

    if (rawContent) {
        var jsonResponse = JSON.parse(rawContent);
        
        if (jsonResponse.success === false) {
            var downstreamErr = jsonResponse.error || {};
            var errDesc = downstreamErr.errorDescription || "An unexpected downstream error occurred.";
            
            // Check specifically for E-0037 (Cancelled/Expired NoI)
            if (errDesc.indexOf("E-0037") !== -1) {
                // Extract OR_ErrorCode & OR_ErrorMessage dynamically using regex
                var codeMatch = errDesc.match(/OR_ErrorCode:\s*([^,]+)/);
                var messageMatch = errDesc.match(/OR_ErrorMessage:\s*(.+)/);
                
                var customCode = codeMatch ? codeMatch[1].trim() : "E-0037";
                var customReason = messageMatch ? messageMatch[1].trim() : errDesc;

                // Flags for policy routing
                context.setVariable("isNetexCallSuccess", "true");
                context.setVariable("isNetexExpiredNoI", "true");

                // Construct full Expired NoI structure
                var expiredNoIPayload = {
                    "duns_id": dunsId,
                    "code": jsonResponse.code,
                    "success": jsonResponse.success,
                    "timeStamp": jsonResponse.timeStamp,
                    "transactionId": jsonResponse.transactionId,
                    "error": {
                        "errorCode": jsonResponse.code,
                        "timeStamp": jsonResponse.timeStamp,
                        "transactionId": jsonResponse.transactionId,
                        "errorSource": downstreamErr.errorSource,
                        "errorType": downstreamErr.errorType,
                        "errorDescription": errDesc,
                        "payload": {
                            "code": customCode,
                            "reason": customReason
                        }
                    }
                };

                var expiredStringified = JSON.stringify(expiredNoIPayload);

                context.setVariable("pubsub.expiredNoI.payload", expiredStringified);
                context.setVariable("pubsub.payload", expiredStringified);

            } else {
               
                context.setVariable("isNetexCallSuccess", "false");
                var errCode = jsonResponse.code || 500;
                var errSource = downstreamErr.errorSource || "OpenReach API Error";
                var errType = downstreamErr.errorType || "HTTP::INTERNAL_SERVER_ERROR";
                
                context.setVariable("netex.error.code", errCode);
                context.setVariable("netex.error.source", errSource);
                context.setVariable("netex.error.type", errType);
                context.setVariable("netex.error.description", errDesc);
            }
        } else {

            context.setVariable("isNetexCallSuccess", "true");
            
            var successPayload = Object.assign({ dunsId: dunsId }, jsonResponse);
            var successStringified = JSON.stringify(successPayload);

            context.setVariable("pubsub.success.payload", successStringified);
            context.setVariable("pubsub.payload", successStringified);
        }
    } else {
        context.setVariable("isNetexCallSuccess", "false");
        context.setVariable("netex.error.code", 500);
        context.setVariable("netex.error.source", "Apigee Gateway");
        context.setVariable("netex.error.type", "HTTP::BAD_GATEWAY");
        context.setVariable("netex.error.description", "Empty response received from inventory service.");
    }
} catch (e) {
    context.setVariable("isNetexCallSuccess", "false");
    context.setVariable("netex.error.code", 500);
    context.setVariable("netex.error.source", "Apigee Gateway");
    context.setVariable("netex.error.type", "HTTP::INTERNAL_SERVER_ERROR");
    context.setVariable("netex.error.description", "Failed to parse inventory service response: " + e.message);
}