
var authHeader = context.getVariable("request.header.Authorization");
var dunsHeader = context.getVariable("request.header.duns");

var missingHeaders = [];
 
if (!authHeader || authHeader.trim() === "") {

    missingHeaders.push("Authorization");

}
 

if (missingHeaders.length > 0) {

    context.setVariable("headers.validation.failed", true);

    context.setVariable("headers.validation.message", "Missing mandatory header(s): " + missingHeaders.join(", ") + ".");

} else {

    context.setVariable("headers.validation.failed", false);

}

 