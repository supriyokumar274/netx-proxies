try {
    var contentType = context.getVariable("request.header.content-type") || "";
    // Set up secure Mailgun authentication headers globally
    context.setVariable("request.header.accept", "application/json");
    context.setVariable("request.header.Authorization", "Basic YXBpOjdhY2NiZjEwZGJmZDJjYWNiYzdjMGE4YzNmNWVjZTQ4LWQ2MzhmYWI3LWZmNjYzYTFh");
    var mailTo = context.getVariable("mailgun.to");
    var mailSubject = context.getVariable("mailgun.subject");
    var mailHtml = context.getVariable("mailgun.htmlPayload");
    var mailFrom = "Mailgun Sandbox <no-reply@netex.cio.mg.vmo2digital.co.uk>";
 
    if (contentType.indexOf("multipart/form-data") > -1) {
        // SCENARIO A: User sent an attachment via form-data.
        // Use the native MultipartForm API to add text parameters safely without breaking the file stream
        var multipartForm = context.getVariable("request.multipartForm");
        if (multipartForm) {
            multipartForm.addParam("from", mailFrom);
            multipartForm.addParam("to", mailTo);
            multipartForm.addParam("subject", mailSubject);
            multipartForm.addParam("html", mailHtml);
        }
    } else {
        // SCENARIO B: User sent a normal raw JSON payload.
        // Convert the entire request to form-urlencoded body format required by Mailgun
        context.setVariable("request.header.content-type", "application/x-www-form-urlencoded");
        var formBody = "from=" + encodeURIComponent(mailFrom) +
                       "&to=" + encodeURIComponent(mailTo) +
                       "&subject=" + encodeURIComponent(mailSubject) +
                       "&html=" + encodeURIComponent(mailHtml);
        context.setVariable("request.content", formBody);
    }
} catch (e) {
    context.setVariable("target.assembly.failed", e.toString());
    throw e;
}