// Mail format set developed by Supriyo accenture
function appendRow(key, val) {
    if (val !== undefined && val !== null && val !== "") {
        var label = key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, function(str){ return str.toUpperCase(); })
            .trim();

        if (label === "Start Time Stamp") label = "Start Timestamp";
        if (label === "End Time Stamp") label = "End Timestamp";
        if (label === "Time Stamp") label = "Time Stamp";

        if (label.indexOf("Gcs") === 0) label = label.replace("Gcs", "GCS");
        if (label.indexOf("Id") === 0) label = label.replace("Id", "ID");
        if (label.indexOf("Cdh") === 0) label = label.replace("Cdh", "CDH");
        if (label === "Sharepoint Path") label = "SharePoint Path";

        var rowHtml = '<tr>';
        rowHtml += '<td style="padding: 4px 8px; font-weight: bold; width: 30%; border: 1px solid #48c0e0; background-color: #ffffff; font-size: 13px;">' + label + '</td>';
        rowHtml += '<td style="padding: 4px 8px; border: 1px solid #48c0e0; background-color: #ffffff; word-break: break-all; font-size: 13px;">' + val + '</td>';
        rowHtml += '</tr>';
        return rowHtml;
    }
    return "";
}

try {
    var jsonString = "";
    var contentType = context.getVariable("request.header.content-type") || "";
    var rawContent = context.getVariable("request.content") || "";

    var kvmAuthToken = context.getVariable("mailgun.api.auth") || "";
    // Fixed warning: Brought condition statement back into unified format blocks
    if (!kvmAuthToken || kvmAuthToken.trim() === "") {
        // set dummy token
        kvmAuthToken = "Basic YXBpOjdhY2NiZjEwZGJmZDJjYWNiYzdjMGE4YzNmh";
    } else {
        kvmAuthToken = kvmAuthToken.trim();
        if (kvmAuthToken.indexOf("Basic ") !== 0) {
            kvmAuthToken = "Basic " + kvmAuthToken;
        }
    }

    context.setVariable("request.header.accept", "application/json");
    context.setVariable("request.header.Authorization", kvmAuthToken);

    if (contentType.indexOf("multipart/form-data") > -1) {
        jsonString = context.getVariable("extracted.multipart.payload");
        if (!jsonString || jsonString === "") {
            jsonString = context.getVariable("request.formparam.payload");
        }
        if (!jsonString || jsonString === "") {
            jsonString = context.getVariable("request.formparam.payload.content");
        }
        
        if (!jsonString || jsonString === "") {
            if (rawContent && rawContent.indexOf('name="payload"') > -1) {
                var searchStr = 'name="payload"';
                var startIndex = rawContent.indexOf(searchStr) + searchStr.length;
                var lookAheadZone = rawContent.substring(startIndex);
                var jsonStartIdx = lookAheadZone.indexOf('{');
                if (jsonStartIdx > -1) {
                    var potentialJson = lookAheadZone.substring(jsonStartIdx);
                    var endBoundaryIdx = potentialJson.indexOf('------');
                    if (endBoundaryIdx > -1) {
                        jsonString = potentialJson.substring(0, endBoundaryIdx).trim();
                    } else {
                        var endBraceIdx = potentialJson.lastIndexOf('}');
                        if (endBraceIdx > -1) {
                            jsonString = potentialJson.substring(0, endBraceIdx + 1).trim();
                        }
                    }
                }
            }
        }
        if (!jsonString) {
            throw new TypeError("Missing 'payload' form parameter inside multipart request.");
        }
    } else {
        jsonString = rawContent;
        if (!jsonString) {
            throw new TypeError("Missing request body content.");
        }
    }

    var incomingPayload;
    try {
        incomingPayload = JSON.parse(jsonString);
    } catch (parseError) {
        throw new SyntaxError("Invalid JSON format inside the request payload.");
    }

    var msgType = incomingPayload.type || "NOTIFICATION";
    var isFailure = (msgType.indexOf("FAILURE") > -1 || msgType.indexOf("ERROR") > -1);

    var baseJobName = msgType.replace(/_SUCCESS|_FAILURE|_ERROR/g, '').trim();

    var cleanTypeLabel = baseJobName
        .toLowerCase()
        .replace(/_/g, ' ')
        .replace(/\b\w/g, function(str) { return str.toUpperCase(); });

    var defaultSubject = isFailure ? "[Failure] " + cleanTypeLabel + " Failure" : "[Success] " + cleanTypeLabel;
    var defaultPara1 = isFailure
        ? baseJobName + " is failed. Kindly find below details :"
        : baseJobName + " is successful. Kindly find below details :";

    var subject = (incomingPayload.email && incomingPayload.email.subject) || defaultSubject;
    var para1 = (incomingPayload.body && incomingPayload.body.para1) || defaultPara1;
    var para2 = (incomingPayload.body && incomingPayload.body.para2) || "";

    var greetingNames = [];
    var toEmailsRaw = [];
    var ccEmailsRaw = [];

    if (incomingPayload.email && incomingPayload.email.to) {
        var rawTo = incomingPayload.email.to;
        if (typeof rawTo === "string") {
            toEmailsRaw = rawTo.replace(/;/g, ",").split(",");
        } else if (Object.prototype.toString.call(rawTo) === '[object Array]') {
            toEmailsRaw = rawTo;
        }
    }

    if (incomingPayload.email && incomingPayload.email.cc) {
        var rawCc = incomingPayload.email.cc;
        if (typeof rawCc === "string") {
            ccEmailsRaw = rawCc.replace(/;/g, ",").split(",");
        } else if (Object.prototype.toString.call(rawCc) === '[object Array]') {
            ccEmailsRaw = rawCc;
        }
    }

    var toEmails = [];
    for (var t = 0; t < toEmailsRaw.length; t++) {
        var emailClean = toEmailsRaw[t] ? toEmailsRaw[t].trim() : "";
        if (emailClean !== "") {
            toEmails.push(emailClean);
            greetingNames.push(emailClean.split('@')[0]);
        }
    }

    if (toEmails.length === 0) {
        toEmails.push("VMO2GCPProdSupport@accenture.com");
        toEmails.push("PIAAdmin@virginmedia.co.uk");
        // toEmails.push("nilay.c.shah@accenture.com");
        // toEmails.push("k.bhakre@accenture.com");
        // toEmails.push("archana.barmeda@accenture.com");
        // toEmails.push("kumari.c.sweta@accenture.com");
        // toEmails.push("bhavika.b.arora@accenture.com");

                
        greetingNames.push("Team");
    }

    var ccEmails = [];
    for (var c = 0; c < ccEmailsRaw.length; c++) {
        var ccClean = ccEmailsRaw[c] ? ccEmailsRaw[c].trim() : "";
        if (ccClean !== "") {
            ccEmails.push(ccClean);
        }
    }

    var greetingStr = "Hi " + greetingNames.join(', ') + ",";
    var mailTo = toEmails.join(', ');
    var mailCc = ccEmails.join(', ');
    var mailSubject = subject;
    
    var mailFrom = "Mailgun Sandbox <no-reply@netex.cio.mg.vmo2digital.co.uk>";

    var html = '<div style="font-family: Arial, sans-serif; font-size: 14px; color: #333; line-height: 1.5;">';
    html += '<p>' + greetingStr + '</p>';
    html += '<p>' + para1 + '</p>';

    if (incomingPayload.metadata && typeof incomingPayload.metadata === 'object') {
        html += '<table style="border-collapse: collapse; width: 100%; max-width: 600px; border: 1px solid #48c0e0; margin-bottom: 15px;">';
        var metadata = incomingPayload.metadata;
        var structuralOrder = [
            "errorCode", "errorSource", "errorType", "errorDescription",
            "fileName", "sharepointPath", "gcsBucket", "gcsPath",
            "dataset", "targetTable", "timeStamp", "startTimeStamp", "endTimeStamp",
            "transactionId", "jobId", "jobName", "jobStatus", "successCount", "failureCount"
        ];

        for (var i = 0; i < structuralOrder.length; i++) {
            var orderedKey = structuralOrder[i];
            if (metadata.hasOwnProperty(orderedKey)) {
                html += appendRow(orderedKey, metadata[orderedKey]);
            }
        }

        for (var rawKey in metadata) {
            if (metadata.hasOwnProperty(rawKey) && structuralOrder.indexOf(rawKey) === -1) {
                html += appendRow(rawKey, metadata[rawKey]);
            }
        }

        html += '</table>';
    }

    if (para2 !== "") {
        html += '<p>' + para2 + '</p>';
    }

    html += '<p style="font-size: 13px; color: #555;">This is an auto generated email, please don\'t reply to this email.</p>';
    html += '<p style="margin: 0;">Regards,</p>';
    html += '<p style="margin: 0; font-weight: bold;">NetEx Support</p>';
    html += '</div>';

    if (contentType.indexOf("multipart/form-data") > -1) {
        var boundaryMatch = contentType.match(/boundary=([^;\s]+)/);
        var boundary = boundaryMatch ? boundaryMatch[1] : "";

        if (!boundary) {
            var firstLine = rawContent.split("\r\n")[0] || rawContent.split("\n")[0];
            boundary = firstLine.replace(/^--/, "").trim();
        }

        var injectionBlock = "--" + boundary + "\r\n" +
                             "Content-Disposition: form-data; name=\"from\"\r\n\r\n" + mailFrom + "\r\n" +
                             "--" + boundary + "\r\n" +
                             "Content-Disposition: form-data; name=\"to\"\r\n\r\n" + mailTo + "\r\n";
                             
        if (mailCc !== "") {
            injectionBlock += "--" + boundary + "\r\n" +
                              "Content-Disposition: form-data; name=\"cc\"\r\n\r\n" + mailCc + "\r\n";
        }
        
        injectionBlock += "--" + boundary + "\r\n" +
                          "Content-Disposition: form-data; name=\"subject\"\r\n\r\n" + mailSubject + "\r\n" +
                          "--" + boundary + "\r\n" +
                          "Content-Disposition: form-data; name=\"html\"\r\n\r\n" + html + "\r\n";

        context.setVariable("request.content", injectionBlock + rawContent);
    } else {
        context.setVariable("request.header.content-type", "application/x-www-form-urlencoded");
        var formBody = "from=" + encodeURIComponent(mailFrom) +
                       "&to=" + encodeURIComponent(mailTo);
                       
        if (mailCc !== "") {
            formBody += "&cc=" + encodeURIComponent(mailCc);
        }
        
        formBody += "&subject=" + encodeURIComponent(mailSubject) +
                    "&html=" + encodeURIComponent(html);
                    
        context.setVariable("request.content", formBody);
    }

} catch (e) {
    context.setVariable("javascript.JS-BuildEmailHtml.failed", e.toString());
    throw e;
}